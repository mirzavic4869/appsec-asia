import LayoutLandingPage from "./landing-layout";

export { LayoutLandingPage };
