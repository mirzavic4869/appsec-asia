import FooterLandingPage from "./footer";

export { FooterLandingPage };
