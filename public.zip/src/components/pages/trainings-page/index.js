import HeroSection from './hero-section'
import ListTrainingSection from './list-section'

export { HeroSection, ListTrainingSection }
