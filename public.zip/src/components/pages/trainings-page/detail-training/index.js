import Training1Section from './training-1'
import Training2Section from './training-2'
import Training3Section from './training-3'
import Training4Section from './training-4'
import Training5Section from './training-5'
import Training6Section from './training-5'
import Training7Section from './training-5'
import Training8Section from './training-5'
import Training9Section from './training-5'
import Training10Section from './training-5'
import Training11Section from './training-5'
import Training12Section from './training-5'
import Training13Section from './training-5'
import Training14Section from './training-5'

export {
  Training1Section,
  Training2Section,
  Training3Section,
  Training4Section,
  Training5Section,
  Training6Section,
  Training7Section,
  Training8Section,
  Training9Section,
  Training10Section,
  Training11Section,
  Training12Section,
  Training13Section,
  Training14Section,
}
