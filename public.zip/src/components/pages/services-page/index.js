import WebDevSection from './web-dev'
import SDLCSection from './sdlc-consulting'
import DigitalForensicSection from './digital-forensic'
import PenetrationTestingSection from './pentest'

export {
  WebDevSection,
  SDLCSection,
  DigitalForensicSection,
  PenetrationTestingSection,
}
