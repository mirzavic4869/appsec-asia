import PostArticle from './post-article'

export { PostArticle }
